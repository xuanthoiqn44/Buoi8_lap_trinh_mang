﻿// Load a MimeMessage from a stream
var message = MimeMessage.Load (stream);
